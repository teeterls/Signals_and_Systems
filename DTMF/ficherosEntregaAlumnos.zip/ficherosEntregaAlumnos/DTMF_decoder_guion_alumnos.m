function pulsacionesDetectadas = DTMF_decoder_guion_alumnos(x)

close all
if nargin == 0
    [x] = generaDTMF([1 4 6],true); % Para que funcione sin par�metros de entrada
end

% Datos tabla DTMF
f = [697,770,852,941,1209 ,1336 ,1477 ,1633];
MATRIZNUMEROS=[['1','2','3','A'];['4','5','6','B'];['7','8','9','C'];['*','0','#','D']];
Fs = 8000;
Ts = 1/Fs;

% Dise�o las frecuencias de corte de los filtros de manera que caigan (por ejemplo) en el punto medio entre cada uno de los tonos
fc =  % puedo almacenar las frecuencias de corte en un vector por ejemplo


xFiltrada = zeros(length(x),length(f)); % Preallocation con ceros

if PLOT % Estos plots puede que no funcionen si hay alg�n nombre que no encaje. Llamad al profesor si ten�is problemas con ellos.
    figure
    stem(f,ones(1,length(f)))
    hold on
    stem(fc,ones(1,length(fc)))
    legend('Frecuencias de los tonos','Frecuencias de corte de los filtros')
    figure
    t = 0:Ts:(size(xFiltrada,1)-1)*Ts;
    plot(t,xFiltrada)
    xlabel('Timepo [s]')
end

% Relleno cada columna de la matriz xFiltrada con la salida de cada uno de los filtros:
% Puede que necesite alg�n tipo de bucle
xFiltrada = �?

if PLOT % Estos plots puede que no funcionen si hay alg�n nombre que no encaje. Llamad al profesor si ten�is problemas con ellos.
    %Les pongo un offset para verlas bien
    xFiltradaPlot= xFiltrada + repmat(1:size(xFiltrada,2),size(xFiltrada,1),1);
    
    figure
    plot(t,xFiltradaPlot)
    xlabel('Timepo [s]')
    title('Salidas de cada filtro con offset (para verlas bien)')
    legend([repmat('salida filtro',size(xFiltradaPlot,2),1) , num2str((1:size(xFiltradaPlot,2))') ])
end

% Rectifico las se�ales tomando su valor absoluto
xFiltradaRectificada =

if PLOT % Estos plots puede que no funcionen si hay alg�n nombre que no encaje. Llamad al profesor si ten�is problemas con ellos.
    figure
    xFiltradaRectificadaPlot= xFiltradaRectificada + repmat(1:size(xFiltrada,2),size(xFiltrada,1),1);
    plot(t,xFiltradaRectificadaPlot)
    xlabel('Timepo [s]')
    title('Salidas de cada filtro Y RECTIFICADAS con offset (para verlas bien)')
    legend([repmat('salida filtro',size(xFiltradaPlot,2),1) , num2str((1:size(xFiltradaPlot,2))') ])
    
end

% Filtro para quedarme con la continua. Para quedarme con la continua filtro todas las se�ales rectificadas de manera que solo pase la componente continua.
% �C�mo puedo saber la frecuencia de corte a utilizar?

xFiltradaRectificadaFiltrada =

if PLOT % Estos plots puede que no funcionen si hay alg�n nombre que no encaje. Llamad al profesor si ten�is problemas con ellos.
    xFiltradaRectificadaFiltradaPlot = xFiltradaRectificadaFiltrada + repmat(1:size(xFiltrada,2),size(xFiltrada,1),1);
    figure
    plot(t,xFiltradaRectificadaFiltradaPlot)
    xlabel('Timepo [s]')
    title('Salidas de cada filtro, rectificada Y FILTRADA con offset (para verlas bien)')
    legend([repmat('Rama ',size(xFiltradaPlot,2),1) , num2str((1:size(xFiltradaPlot,2))') ])
end


% Detecto las posiciones de cada se�al en las que tengo componente de se�al
% diferente de cero.
detectorThreshold = .25; % Para no comparar con 0, puedo comparar con un cierto umbral. Quiz� haya que afinarlo mirando la se�al

xDetectada =
if PLOT % Estos plots puede que no funcionen si hay alg�n nombre que no encaje. Llamad al profesor si ten�is problemas con ellos.
    xDetectadaPlot= xDetectada + repmat(1:size(xDetectada,2),size(xDetectada,1),1);
    figure
    plot(t,xDetectadaPlot)
    xlabel('Timepo [s]')
    title('Entradas al detector con offset (para verlas bien)')
    legend([repmat('Rama ',size(xFiltradaPlot,2),1) , num2str((1:size(xFiltradaPlot,2))') ])
end

% Detecto las filas mirando las salidas de las cuatro primeras se�ales
filasPulsadas =

% Detecto las columnas mirando las salidas de las cuatro �ltimas se�ales
columnasPulsadas =

% Para el caso de haber pulsado los n�meros 1 4 6, el resultado de los
% vectores filasPulsadas y columnasPulsadas ser�a:
%
%  columnasPulsadas =
%
%      1
%      1
%      3
%
%   filasPulsadas =
%
%      1
%      2
%      2

% Decodifico los valores
pulsacionesDetectadas = MATRIZNUMEROS(sub2ind(size(MATRIZNUMEROS),filasPulsadas, columnasPulsadas))'
disp(['Las pulsaciones detectadas son: ',num2str(pulsacionesDetectadas)])
